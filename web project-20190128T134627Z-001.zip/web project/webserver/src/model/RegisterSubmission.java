package model;

public class RegisterSubmission extends SmartSerializable
{
	private static final long serialVersionUID = 1L;

}

package model;

public class FAQSubmission extends SmartSerializable
{
	private static final long serialVersionUID = 1L;

}

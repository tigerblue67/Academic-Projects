package model;

public class AboutUsModel extends SmartSerializable
{
	private static final long serialVersionUID = 1L;
	
	public String title;
	public String desc;
	public String img;
	public String link;
	public String URL;
}

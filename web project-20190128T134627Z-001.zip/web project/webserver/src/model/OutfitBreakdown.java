package model;

public class OutfitBreakdown extends SmartSerializable
{
	public static final long serialVersionUID = 1L;
	public String mainIMG, mainTitle, mainDesc;
	public String sec1Title, sec1Desc, sec1IMG, sec1URL;
	public String sec2Title, sec2Desc, sec2IMG, sec2URL;
	public String sec3Title, sec3Desc, sec3IMG, sec3URL;
	public String sec4Title, sec4Desc, sec4IMG, sec4URL;
	public String sec5Title, sec5Desc, sec5IMG, sec5URL;
	public String sec6Title, sec6Desc, sec6IMG, sec6URL;

}

package model;

public class ExampleModel extends SmartSerializable
{
	private static final long serialVersionUID = 1L;

}

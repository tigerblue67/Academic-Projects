package model;

public class Comment extends SmartSerializable
{
	private static final long serialVersionUID = 1L;
	
	public String username, comment, uniqueid;
}

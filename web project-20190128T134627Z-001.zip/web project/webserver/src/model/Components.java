package model;

import java.io.File;

public class Components extends SmartSerializable
{
	private static final long serialVersionUID = 1L;
	public String uniqueID;
	public String title;
	public String description;
	public String picture;
	public String link;

}
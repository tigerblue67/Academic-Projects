package model;

public class LoginSubmission extends SmartSerializable
{
	private static final long serialVersionUID = 1L;

}

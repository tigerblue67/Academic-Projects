package wombat.crm;
/**
 * Possible actions within the CRM system
 *
 */
public enum Action {
	MAINMENU,
	EXIT,
	CUSTOMERSEARCH,
	CUSTOMERADD
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data.OleDb;
using System.Collections;

namespace WindowsFormsApplication1
{
    class bookIngaRRAY
    {
        public static ArrayList arrayListBookingDetails = new ArrayList();

    }
}

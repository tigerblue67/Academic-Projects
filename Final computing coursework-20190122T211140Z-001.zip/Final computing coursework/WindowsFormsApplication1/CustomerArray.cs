﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace WindowsFormsApplication1
{
    class CustomerArray
    {
        public static ArrayList arrayListCustomerDetails = new ArrayList();
    }
}

module.exports = {
    subtract: function(x,y) {
        return x-y;
    }
}

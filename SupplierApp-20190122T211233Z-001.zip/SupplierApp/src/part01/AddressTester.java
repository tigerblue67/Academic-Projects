package part01;

public class AddressTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

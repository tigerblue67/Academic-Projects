package part01;

public class ProductTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

<?php
// Calculator Add Function - no error checking
function add($x, $y)
{
	return $x+$y;
}

require 'test_helper'

class SquareControllerTest < ActionDispatch::IntegrationTest
  # test "square Controller" do
  #   get "square/new?x=4"
  #   assert_equal "16", @respone.body
end

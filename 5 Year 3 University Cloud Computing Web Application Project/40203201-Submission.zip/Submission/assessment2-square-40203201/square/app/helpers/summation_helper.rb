module SummationHelper
end

module SquareHelper
end

class SummationController < ApplicationController
  def index
  end
end
